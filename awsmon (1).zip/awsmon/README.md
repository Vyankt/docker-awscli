# AWS Monitor — Phase 1 & 2 (Foundation + Auth/RBAC)

Multi-tenant AWS monitoring dashboard. This package contains a **working,
runnable** Phase 1 (foundation) + Phase 2 (JWT auth + RBAC) backend, plus a
Phase 5-preview frontend (black/green themed dashboard with an **account-wise
heat map**, currently backed by mock data until Phase 4's real CloudWatch
collector is added).

## What's real vs. mocked right now

| Piece | Status |
|---|---|
| FastAPI app, Docker, Postgres, config, health check | ✅ Real |
| JWT login/refresh, bcrypt passwords, RBAC (admin/editor/viewer/readonly) | ✅ Real |
| Organizations & AWS Accounts CRUD | ✅ Real |
| Frontend: black/green theme, login, account-wise heat map UI | ✅ Real |
| Heat map **values** (CPU/error rate per resource) | 🟡 Mocked — random values with correct color thresholds. Wiring to real CloudWatch → VictoriaMetrics is Phase 4. |
| STS AssumeRole, CloudWatch collector, VictoriaMetrics writes | ⏳ Not built yet (Phase 3-4) |

## Quick start — Docker (recommended)

```bash
cd awsmon
cp backend/.env.example backend/.env
docker compose up --build
```

Then, in a second terminal, seed the roles + a demo account:

```bash
docker compose exec backend python -m app.utils.seed
```

- Backend: http://localhost:8000 (docs at http://localhost:8000/docs)
- Frontend: http://localhost:5173
- Login with: `admin@demo.local` / `Admin@12345`

## Quick start — VS Code, no Docker for the app itself

1. Open the `awsmon` folder in VS Code.
2. Install recommended extensions when prompted (Python, Docker, ESLint).
3. Start only the data stores in Docker:
   ```bash
   docker compose up -d postgres victoriametrics
   ```
4. Backend:
   ```bash
   cd backend
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   cp .env.example .env
   python -m app.utils.seed
   uvicorn app.main:app --reload
   ```
   Or press **F5** in VS Code (uses `.vscode/launch.json`, "FastAPI: uvicorn").
5. Frontend:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
6. Open http://localhost:5173, log in with the demo admin above.

## Project layout

```
awsmon/
├── backend/
│   ├── app/
│   │   ├── main.py            # FastAPI app + router registration
│   │   ├── config.py          # env-based settings
│   │   ├── database.py        # SQLAlchemy engine/session
│   │   ├── dependencies.py    # get_current_user, require_roles (RBAC)
│   │   ├── models/            # organization, role, user, aws_account
│   │   ├── schemas/           # pydantic request/response models
│   │   ├── routers/           # auth, users, roles, organizations, accounts, dashboard, health
│   │   ├── services/          # heatmap_service (mock now, real in Phase 4)
│   │   ├── auth/              # jwt_handler, password, permissions
│   │   └── utils/seed.py      # seeds RBAC roles + demo org/user/account
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── pages/             # Login, Dashboard
│   │   ├── components/        # AccountHeatmap.jsx
│   │   ├── api/client.js      # axios + auth token handling
│   │   └── styles/theme.css   # black/green design tokens
│   └── Dockerfile
├── .vscode/                   # launch.json, settings.json, extensions.json
└── docker-compose.yml         # postgres + victoriametrics + backend + frontend
```

## RBAC roles

- **admin** — manage users, org, accounts, alerts
- **editor** — manage accounts/alerts, view/edit dashboards
- **viewer** — read-only dashboard access
- **readonly** — same as viewer, reserved for external/audit access

Enforced via `Depends(require_roles("admin", "editor"))` on protected routes.

## API endpoints so far

```
POST   /api/auth/register
POST   /api/auth/login
POST   /api/auth/refresh
GET    /api/users/me
GET    /api/users
POST   /api/users              (admin)
PATCH  /api/users/{id}         (admin)
GET    /api/roles
GET    /api/organizations/me
PATCH  /api/organizations/me   (admin)
GET    /api/accounts
POST   /api/accounts           (admin, editor)
DELETE /api/accounts/{id}      (admin)
GET    /api/dashboard/heatmap  (account-wise heat map)
GET    /health
```

## Theme tokens (black & green)

Defined in `frontend/src/styles/theme.css`:

```css
--bg-primary: #0d1117;
--accent-green: #00ff9c;
--status-critical: #ff4d4f;
--status-warning: #ffb020;
--status-healthy: #00ff9c;
```

## Next up (Phase 3-5)

- Phase 3: STS AssumeRole + cross-account IAM validation
- Phase 4: CloudWatch collector (EC2/RDS/ALB/Lambda) → VictoriaMetrics writes
- Phase 5: replace `heatmap_service.py` mock values with real VictoriaMetrics
  queries, add alert rules + SMTP notifications, dashboard summary cards

Say "पुढचा phase दे" (or "continue Phase 3") in chat and I'll add those files
into this same structure.
