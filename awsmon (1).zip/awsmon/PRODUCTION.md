# Production Deployment — Fast Path

This gets you live on a single VPS (DigitalOcean/AWS EC2/Hetzner, 2 vCPU / 4GB
RAM is plenty to start) with HTTPS, in about 15 minutes. Copy-paste the
commands in order.

## 0. Before you touch a server

- Point your domain's **A record** at the server's public IP now (DNS
  propagation takes a few minutes, so do it first).
- Have the code on the server: `git clone` your repo, or `scp` the folder up.

## 1. Install Docker on the server (Ubuntu)

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker
```

## 2. Configure secrets

```bash
cd awsmon
cp .env.prod.example .env.prod
```

Edit `.env.prod`:
- `DOMAIN` → your real domain (must match what's in your DNS + `Caddyfile`)
- `POSTGRES_PASSWORD` → generate one: `openssl rand -base64 32`
- `JWT_SECRET_KEY` → generate one: `python3 -c "import secrets; print(secrets.token_urlsafe(64))"`

Edit `Caddyfile` line 3, replace `your-domain.com` with your real domain.

**Never reuse the demo `JWT_SECRET_KEY` or `Admin@12345` password from the
dev setup in production.** Anyone who knows those can forge tokens.

## 3. Bring it up

```bash
docker compose --env-file .env.prod -f docker-compose.prod.yml up -d --build
```

Caddy will automatically request and renew a Let's Encrypt HTTPS cert for
your domain the first time it starts — no manual cert steps.

## 4. Seed the database (first deploy only)

```bash
docker compose -f docker-compose.prod.yml exec backend python -m app.utils.seed
```

**Immediately after**, log in as `admin@demo.local` / `Admin@12345`,
change that password, or better — create your real admin user via
`POST /api/auth/register` and delete/deactivate the demo one.

## 5. Verify

```bash
curl https://your-domain.com/health
```
Should return `{"status": "ok", "database": "ok"}`. Open `https://your-domain.com`
in a browser and log in.

## 6. Watch logs / confirm it's stable

```bash
docker compose -f docker-compose.prod.yml logs -f backend
docker compose -f docker-compose.prod.yml ps
```

---

## What this setup already gives you

- HTTPS via Caddy, auto-renewing certs, single public entrypoint
- Postgres and VictoriaMetrics **not** exposed to the internet (no published
  ports — only reachable inside the Docker network)
- Backend runs under gunicorn + 4 uvicorn workers, not the dev `--reload`
  server
- `restart: always` on every service — survives server reboots and crashes
- Same-origin frontend/API (Caddy proxies `/api/*` to the backend on the
  same domain), so there's no CORS exposure to lock down later

## What you should still do this week (not blocking go-live)

1. **Database backups.** Nothing is backed up automatically yet. Simplest
   cron job:
   ```bash
   docker compose -f docker-compose.prod.yml exec -T postgres \
     pg_dump -U awsmon awsmon > backups/awsmon_$(date +%F).sql
   ```
   Put that in `crontab -e`, run nightly, and ship the file off-box (S3,
   rsync elsewhere) — a backup that lives only on the same disk as the DB
   isn't really a backup.

2. **Migrations, not `create_all`.** Right now schema is created via
   SQLAlchemy's `create_all()` on startup, which is fine for the first
   deploy but won't handle future column/table changes safely. Before your
   first schema change, set up Alembic (`alembic init`) so upgrades don't
   require dropping data.

3. **Firewall.** Even though Postgres/VM ports aren't published in Compose,
   lock down the VPS itself: `ufw allow 22,80,443/tcp` and deny the rest.

4. **Monitoring the monitor.** Something outside this stack should alert you
   if the box itself goes down — a cheap uptime checker (UptimeRobot,
   Better Uptime, etc.) pinging `/health` is enough for now.

5. **Rotate the demo credentials** if you haven't already (step 4 above) —
   this is the one that actually matters most for security, do it first.

## If something's broken right now

```bash
# See what's failing
docker compose -f docker-compose.prod.yml ps
docker compose -f docker-compose.prod.yml logs backend --tail=100
docker compose -f docker-compose.prod.yml logs caddy --tail=50

# Common issue: Caddy can't get a cert because DNS hasn't propagated yet.
# Check with:
dig +short your-domain.com

# Restart a single service without rebuilding:
docker compose -f docker-compose.prod.yml restart backend
```
