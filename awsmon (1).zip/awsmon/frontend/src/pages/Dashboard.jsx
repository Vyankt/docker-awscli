import { useEffect, useState } from "react";
import AccountHeatmap from "../components/AccountHeatmap";
import { fetchHeatmap } from "../api/client";

export default function Dashboard() {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true);
    try {
      const data = await fetchHeatmap();
      setAccounts(data);
      setError("");
    } catch (err) {
      setError(err?.response?.data?.detail || "Failed to load heat map");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 30000); // refresh every 30s
    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
        <h2 style={{ margin: 0 }}>Account Heat Map</h2>
        <button className="btn" onClick={load}>
          Refresh
        </button>
      </div>

      <div className="card">
        {loading && <p style={{ color: "var(--text-secondary)" }}>Loading...</p>}
        {error && <p style={{ color: "var(--status-critical)" }}>{error}</p>}
        {!loading && !error && <AccountHeatmap accounts={accounts} />}
      </div>
    </div>
  );
}
