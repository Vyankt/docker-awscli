from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, engine
from app.routers import auth, users, roles, organizations, accounts, health, dashboard

# Import models so they register with Base.metadata before create_all
from app.models import organization, role, user, aws_account  # noqa: F401

app = FastAPI(title=settings.app_name, debug=settings.debug)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(roles.router)
app.include_router(organizations.router)
app.include_router(accounts.router)
app.include_router(dashboard.router)


@app.on_event("startup")
def on_startup():
    # Phase 1-2: create_all for fast local iteration.
    # Swap to Alembic migrations once schema stabilizes (Phase 3+).
    Base.metadata.create_all(bind=engine)


@app.get("/")
def root():
    return {"app": settings.app_name, "status": "running"}
