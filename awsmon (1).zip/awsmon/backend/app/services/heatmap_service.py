"""
Account-wise heat map data builder.

Phase 1-2: returns mock data so the frontend heat map is fully wired end to
end from day one.

Phase 4-5: this will query VictoriaMetrics (via victoriametrics/query.py) for
real EC2 / RDS / ALB / Lambda metrics per AWS account and replace
_mock_resources() with real values, keeping the same response shape so the
frontend does not need to change.
"""
import random
from sqlalchemy.orm import Session

from app.models.aws_account import AwsAccount


def _status_for(value: float) -> str:
    if value >= 80:
        return "critical"
    if value >= 50:
        return "warning"
    return "healthy"


def _mock_resources(account: AwsAccount) -> list[dict]:
    resource_defs = [
        ("ec2", "i-0a1b2c3d", "cpu"),
        ("ec2", "i-0e4f5g6h", "cpu"),
        ("rds", "db-primary-1", "cpu"),
        ("alb", "app-lb-1", "request_error_rate"),
        ("lambda", "fn-image-resize", "error_rate"),
    ]
    resources = []
    for rtype, rid, metric in resource_defs:
        value = round(random.uniform(5, 98), 1)
        resources.append(
            {
                "type": rtype,
                "id": rid,
                "metric": metric,
                "value": value,
                "status": _status_for(value),
            }
        )
    return resources


def build_account_heatmap(db: Session, organization_id: int) -> list[dict]:
    accounts = (
        db.query(AwsAccount).filter(AwsAccount.organization_id == organization_id).all()
    )

    heatmap = []
    for account in accounts:
        resources = _mock_resources(account)
        overall_score = round(sum(r["value"] for r in resources) / len(resources), 1) if resources else 0
        heatmap.append(
            {
                "account_id": account.account_id,
                "account_name": account.account_name,
                "region": account.default_region,
                "overall_status": _status_for(overall_score),
                "resources": resources,
            }
        )
    return heatmap
