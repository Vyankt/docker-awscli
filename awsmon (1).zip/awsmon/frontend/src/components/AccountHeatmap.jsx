export default function AccountHeatmap({ accounts }) {
  if (!accounts || accounts.length === 0) {
    return <p style={{ color: "var(--text-secondary)" }}>No AWS accounts connected yet.</p>;
  }

  return (
    <div>
      {accounts.map((account) => (
        <div key={account.account_id} className="heatmap-account">
          <div className="heatmap-account-header">
            <span className={`status-dot status-${account.overall_status}`} />
            <span className="heatmap-account-name">{account.account_name}</span>
            <span className="heatmap-account-id">
              {account.account_id} · {account.region}
            </span>
          </div>

          <div className="heatmap-grid">
            {account.resources.map((r) => (
              <div key={`${account.account_id}-${r.id}`} className={`heatmap-cell cell-${r.status}`}>
                <div className="heatmap-cell-type">{r.type}</div>
                <div className="heatmap-cell-id">{r.id}</div>
                <div className="heatmap-cell-value">
                  <span className={`status-dot status-${r.status}`} />
                  {r.value}%
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
