from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.services.heatmap_service import build_account_heatmap

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/heatmap")
def get_heatmap(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """
    Account-wise heat map: one row per AWS account, each containing its
    resources (EC2 / RDS / ALB / Lambda) color-coded by status.
    """
    return {"accounts": build_account_heatmap(db, current_user.organization_id)}
