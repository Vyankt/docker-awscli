from pydantic import BaseModel, ConfigDict


class OrganizationOut(BaseModel):
    id: int
    name: str
    slug: str

    model_config = ConfigDict(from_attributes=True)


class OrganizationUpdate(BaseModel):
    name: str | None = None


class AwsAccountCreate(BaseModel):
    account_id: str
    account_name: str
    role_arn: str
    external_id: str | None = None
    default_region: str = "ap-south-1"


class AwsAccountOut(BaseModel):
    id: int
    account_id: str
    account_name: str
    default_region: str

    model_config = ConfigDict(from_attributes=True)
