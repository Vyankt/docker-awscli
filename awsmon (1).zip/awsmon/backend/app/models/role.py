from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship

from app.database import Base


class Role(Base):
    """
    Fixed role set for RBAC: admin, editor, viewer, readonly.
    Seeded via alembic/migration or startup seeder.
    """

    __tablename__ = "roles"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False, unique=True)  # admin | editor | viewer | readonly
    description = Column(String(255), nullable=True)

    users = relationship("User", back_populates="role")


# Permission matrix used by services/routers when a finer check than
# require_roles() is needed. Kept in code (not DB) for Phase 1-2 simplicity.
ROLE_PERMISSIONS = {
    "admin": {"manage_users", "manage_org", "manage_accounts", "manage_alerts", "view_all", "edit_all"},
    "editor": {"manage_accounts", "manage_alerts", "view_all", "edit_all"},
    "viewer": {"view_all"},
    "readonly": {"view_all"},
}
