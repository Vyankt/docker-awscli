from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, func
from sqlalchemy.orm import relationship

from app.database import Base


class AwsAccount(Base):
    __tablename__ = "aws_accounts"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)

    account_id = Column(String(12), nullable=False)   # 12-digit AWS account id
    account_name = Column(String(255), nullable=False)
    role_arn = Column(String(255), nullable=False)      # cross-account IAM role to assume
    external_id = Column(String(255), nullable=True)    # STS AssumeRole external id
    default_region = Column(String(50), default="ap-south-1")

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    organization = relationship("Organization", back_populates="aws_accounts")

    __table_args__ = ()
