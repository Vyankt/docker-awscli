"""
Run once after the DB is up:

    python -m app.utils.seed

Creates the fixed RBAC roles, plus (optionally) a demo org / admin user /
AWS account so the dashboard has something to show immediately.
"""
from app.database import Base, engine, SessionLocal
from app.models.role import Role
from app.models.organization import Organization
from app.models.user import User
from app.models.aws_account import AwsAccount
from app.auth.password import hash_password

ROLES = [
    ("admin", "Full access: manage users, org, accounts, alerts"),
    ("editor", "Manage AWS accounts and alerts, view/edit dashboards"),
    ("viewer", "Read-only access to dashboards and metrics"),
    ("readonly", "Strict read-only, same as viewer, reserved for external auditors"),
]


def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        for name, desc in ROLES:
            if not db.query(Role).filter(Role.name == name).first():
                db.add(Role(name=name, description=desc))
        db.commit()

        if not db.query(Organization).filter(Organization.slug == "demo-org").first():
            org = Organization(name="Demo Org", slug="demo-org")
            db.add(org)
            db.flush()

            admin_role = db.query(Role).filter(Role.name == "admin").first()
            admin_user = User(
                email="admin@demo.local",
                full_name="Demo Admin",
                hashed_password=hash_password("Admin@12345"),
                organization_id=org.id,
                role_id=admin_role.id,
            )
            db.add(admin_user)

            db.add(
                AwsAccount(
                    organization_id=org.id,
                    account_id="111122223333",
                    account_name="prod-account-1",
                    role_arn="arn:aws:iam::111122223333:role/AwsMonitorCrossAccountRole",
                    default_region="ap-south-1",
                )
            )
            db.commit()
            print("Seeded demo-org with admin@demo.local / Admin@12345")
        else:
            print("Demo org already exists, skipping demo seed")

        print("Roles seeded:", [r.name for r in db.query(Role).all()])
    finally:
        db.close()


if __name__ == "__main__":
    seed()
