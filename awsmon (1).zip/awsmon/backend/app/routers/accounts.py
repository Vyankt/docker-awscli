from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, require_roles
from app.models.aws_account import AwsAccount
from app.models.user import User
from app.schemas.organization import AwsAccountCreate, AwsAccountOut

router = APIRouter(prefix="/api/accounts", tags=["aws-accounts"])


@router.get("", response_model=list[AwsAccountOut])
def list_accounts(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return (
        db.query(AwsAccount)
        .filter(AwsAccount.organization_id == current_user.organization_id)
        .all()
    )


@router.post("", response_model=AwsAccountOut, status_code=201)
def create_account(
    payload: AwsAccountCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin", "editor")),
):
    account = AwsAccount(
        organization_id=current_user.organization_id,
        account_id=payload.account_id,
        account_name=payload.account_name,
        role_arn=payload.role_arn,
        external_id=payload.external_id,
        default_region=payload.default_region,
    )
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


@router.delete("/{account_id}", status_code=204)
def delete_account(
    account_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin")),
):
    account = (
        db.query(AwsAccount)
        .filter(AwsAccount.id == account_id, AwsAccount.organization_id == current_user.organization_id)
        .first()
    )
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    db.delete(account)
    db.commit()
