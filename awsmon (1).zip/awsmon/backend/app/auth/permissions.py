from app.models.role import ROLE_PERMISSIONS
from app.models.user import User


def has_permission(user: User, permission: str) -> bool:
    role_name = user.role.name if user.role else None
    if role_name is None:
        return False
    return permission in ROLE_PERMISSIONS.get(role_name, set())
